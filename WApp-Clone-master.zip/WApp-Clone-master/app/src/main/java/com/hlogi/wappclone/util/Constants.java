package com.hlogi.wappclone.util;

public class Constants {

    public static final String ACCOUNT_TYPE = "com.hlogi.wappclone";
    public static final String ACCOUNT_NAME = "WApp Clone";
}
